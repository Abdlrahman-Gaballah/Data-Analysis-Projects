BTECH POWER BI DESIGN PACK

1) Import BTech_Dashboard_Theme.json:
   Power BI -> View -> Themes -> Browse for themes

2) Use BTech_Dashboard_Background.svg as the page background:
   Insert -> Image, or use it as the page wallpaper/background.

3) The SVG is a visual layout/background based on the supplied screenshot.
   Replace the placeholder text/graphics with native Power BI visuals for live data.

4) The JSON controls the main dark/orange/green/purple theme.

Recommended page size: 1536 x 1024.
